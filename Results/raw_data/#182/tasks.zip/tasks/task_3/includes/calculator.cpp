//
// Created by maximilian on 02.09.24.
//

#include "calculator.h"

#include <complex>
#include <cmath>


double calculate(int mode, double a, double b) {
 
    switch (mode) {
        case 0:
            return add(a, b);
        break;
        case 1:
            return mult(a, b);
        break;
        case 2:
            return divide(a, b);
        break;
        case 3:
            return pow(a, b);
        break;
        default:
            return 0.0;
    }
}


double add(double a, double b) {
    return a + b;
}

double mult(double a, double b) {
    return a * b;
}

double divide(double a, double b) {
    return a / b;
}

double pow(double a, double b) {
    double result = a;
    for(int i = 0; i < b-1; i++) {
        result = result * a;
    }

    return result;
}