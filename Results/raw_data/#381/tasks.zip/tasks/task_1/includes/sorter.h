//
// Created by maximilian on 02.09.24.
//

#ifndef SORTER_H
#define SORTER_H

#include <iostream>


void sort(int *arr, int size);



#endif //SORTER_H
