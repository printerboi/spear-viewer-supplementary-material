//
// Created by maximilian on 02.09.24.
//

#include "converter.h"

#include <iostream>
#include <ostream>
#include <string>


void handler(int mode, double value) {
    std::string symbol;

    switch (mode)
    {
    case 0:
        value = celsiusToFahrenheit(value);
        symbol = "°F";
        break;
    case 1:
        value = fahrenheitToCelsius(value);
        symbol = "°C";
        break;
    case 2:
        value = celsiusToKelvin(value);
        symbol = "K";
        break;
    case 3:
        value = fahrenheitToKelvin(value);
        symbol = "K";
        break;
    
    }
    std::cout << value << " " << symbol << std::endl;
}

double celsiusToFahrenheit(double value) {
    double fahrenheitValue = (value * 9/5) + 32;
    return fahrenheitValue;
}

double fahrenheitToCelsius(double value) {
    return (value - 32) * 5/9;
}

double celsiusToKelvin(double value) {
    return value + 273.15;
}

double fahrenheitToKelvin(double fahrenheit) {
    return (fahrenheit - 32) * 5/9 + 273.15;
}

