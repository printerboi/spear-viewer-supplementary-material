//
// Created by maximilian on 02.09.24.
//

#include "calculator.h"

#include <complex>
#include <cmath>


double calculate(int mode, double a, double b) {
    double result = 0.0;

    switch (mode) {
        case 0:
            return a + b;
        break;
        case 1:
            return a * b;
        break;
        case 2:
            return a / b;
        break;
        case 3:
            return std::pow(a, b);
    break;
        default:
            return result = 0.0;
    }
}


double add(double a, double b) {
    double c;
    c = a + b;
    return c;
}

double mult(double a, double b) {
    return a * b;
}

double divide(double a, double b) {
    return a / b;
}

double pow(double a, double b) {
    return std::pow(a, b);
}