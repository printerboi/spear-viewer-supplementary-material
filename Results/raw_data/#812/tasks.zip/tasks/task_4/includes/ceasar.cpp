#include "ceasar.h"


char rotate(char c, int shift) {
    char rotated = c;

    if (islower(c)) {
        char offset = 'a';
        char base = c - offset;
        char globaloffset = 'a';
        rotated = (base + shift) % 26 + globaloffset;
    }

    if (isupper(c)) {
        char offset = 'A';
        rotated = (c - 'A' + shift) % 26 + offset;
    }

    if (isdigit(c)) {
        rotated = (c - '0' + shift) % 10 + '0';
    }

    return rotated;
}

char rotate_2(char c, int shift) {
    char value = (int(c)-26+(65-shift))%65+26;

    if (isdigit(c)) {
        value = (c - '0' + shift) % 10 + '0';
    }

    return value;
}
std::string encrypt(std::string plainText, int shift){
  std::string cipherText;

  for(int i = 0; i < plainText.length(); i++) {
      char c = plainText.at(i);
      char rotated = rotate_2(c, shift);
      cipherText += rotated;
  }

  return cipherText;
}
