//
// Created by maximilian on 02.09.24.
//

#include "calculator.h"

#include <complex>
#include <cmath>


double calculate(int mode, double a, double b) {
    double result = 0.0;

    switch (mode) {
        case 0:
            result = add(a, b);
        break;
        case 1:
            result = mult(a, b);
        break;
        case 2:
            result = divide(a, b);
        break;
        case 3:
            result = pow(a, b);
        break;
        default:
            result = 0.0;
    }

    return result;
}


double add(double a, double b) {
    double c;
    c = a + b;
    return c;
}

double mult(double a, double b) {
    return a * b;
}

double divide(double a, double b) {
    return a / b;
}

double pow(double a, double b) {
    
    /*
    double result = a;
    for(int i = 0; i < b-1; i++) {
        result = result * a;
    }
    
   
   double result = 1;
   double base = a;
   int exp = int(b);
   for (;;)
    {
        if (exp & 1)
            result *= base;
        exp >>= 1;
        if (!exp)
            break;
        base *= base;
    }
    */
   
   if (b == 0)
        return 1;
    double res = pow(a, b / 2);
    // If we find out that b is odd, it basically does this :
    /*   
        if B = 5 : b/2 = 2, i.e,( a^2 * a^2 * a ) == a ^ 5
    */
    if (int(b) % 2)
        return res * res * a;
    
    else
        return res * res;
}