//
// Created by maximilian on 02.09.24.
//

#ifndef CALCULATOR_H
#define CALCULATOR_H



double calculate(int mode, double a, double b);

double add(double a, double b);

double mult(double a, double b);

double divide(double a, double b);

double power(double a, double b);


#endif //CALCULATOR_H
