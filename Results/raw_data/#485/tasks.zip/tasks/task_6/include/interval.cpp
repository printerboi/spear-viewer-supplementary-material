//
// Created by maximilian on 21.06.24.
//


#include "interval.h"
const Interval Interval::empty    = Interval(+infinity, -infinity);
const Interval Interval::universe = Interval(-infinity, +infinity);
