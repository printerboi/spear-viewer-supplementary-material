//
// Created by maximilian on 21.06.24.
//

#include "color.h"
void write_color(std::ostream& out, const color& pixel_color) {


	// Translate the [0,1] component values to the byte range [0,255].
	int rbyte = int(255.999 * pixel_color.x());
	int gbyte = int(255.999 * pixel_color.y());
	int bbyte = int(255.999 * pixel_color.z());

	// Write out the pixel color components.
	out << rbyte << ' ' << gbyte << ' ' << bbyte << '\n';
}
