#include "include/Camera.h"
#include "include/Sphere.h"
#include "include/hitable_list.h"

const float pi = 3.1415926535897932385;


inline float degrees_to_radians(float degrees) {
    return degrees * pi / 180.0;
}


int main()
{

    float aspect_ratio = 16.0 / 9.0;
    int width = 400;
    vec3 camera_center = vec3(0, 0, 0);

    hittable_list world;

    world.add(make_shared<Sphere>(point3(0,0,-1), 0.5));
    world.add(make_shared<Sphere>(point3(0,-100.5,-1), 100));

    Camera camera = Camera(width, aspect_ratio, camera_center);
    int height = camera.get_height();


    std::cout << "P3\n" << "400" << " " << height << "\n255\n";

    for(int y = 0; y < height; y++) {
        std::clog << "\rProgress: (" << y+1 << "/" << height << ")" << std::flush;
        for(int x = 0; x < 400; x++) {
            float redChannel = (float) x / (width - 1);
            float greenChannel = (float) y / (width - 1);
            float blueChannel = (float) (y+x) / (width - 1);

            auto pixel_color = camera.construct_ray_for_pixel(y, x).getColor(world);
            write_color(std::cout, pixel_color);
        }
    }

    std::clog << "\rFinished.                   \n";

    vec3(0, 0, 0);

    return 0;
}
