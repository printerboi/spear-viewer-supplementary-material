#include "ceasar.h"


char rotate(char c, int shift) {
    char rotated = c;
    int mod = 26;
    char offset = 'a';

    if (isdigit(c)) {
        offset = '0';
        mod = 10;
    }

    if (isupper(c)) {
        offset = 'A';
    }

    if (!isupper(c) && !islower(c) && !isdigit(c)) {
        return c;
    }

    return (c - offset + shift) % mod + offset;
}

std::string encrypt(std::string plainText, int shift){
  std::string cipherText;
  int len = plainText.length();

  for(int i = 0; i < len; i++) {
      char c = plainText[i];
      char rotated = rotate(c, shift);
      cipherText += rotated;
  }

  return cipherText;
}
