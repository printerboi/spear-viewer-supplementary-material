#include <stdio.h>
#include "includes/converter.h"

int main() {
    printf("====== Temperature calculator ======\n");
    printf("Select mode:\n");
    printf("\t 0) Celsius to Fahrenheit\n");
    printf("\t 1) Fahrenheit to Celsius\n");
    printf("\t 2) Celsius to Kelvin\n");
    printf("\t 3) Fahrenheit to Kelvin\n");
    int mode = 0;
    double value = 255;

    printf("Insert Value: ");

    handler(mode, value);

    return 0;
}
