//
// Created by maximilian on 02.09.24.
//

#ifndef CONVERTER_H
#define CONVERTER_H



void handler(int mode, double value);

double celsiusToFahrenheit(double celsius);

double fahrenheitToCelsius(double fahrenheit);

double celsiusToKelvin(double celsius);

double fahrenheitToKelvin(double fahrenheit);



#endif //CONVERTER_H
