//
// Created by maximilian on 02.09.24.
//

#include "converter.h"

#include <stdio.h>


void handler(int mode, double value) {
    double temp = value;

    if(mode == 0) {
        temp = celsiusToFahrenheit(temp);
    }else if(mode == 1) {
        temp = fahrenheitToCelsius(temp);
    }else if(mode == 2) {
        temp = celsiusToKelvin(temp);
    }else if(mode == 3) {
        temp = fahrenheitToKelvin(temp);
    }

    printf("%f ", temp);

    if(mode == 0) {
        printf("°F");
    }else if(mode == 1) {
        printf("°C");
    }else if(mode == 2) {
        printf("K");
    }else if(mode == 3) {
        printf("K");
    }

    printf("\n");
}

double celsiusToFahrenheit(double value) {
    double fahrenheitValue = (value * 9/5) + 32;
    return fahrenheitValue;
}

double fahrenheitToCelsius(double value) {
    return (value - 32) * 5/9;
}

double celsiusToKelvin(double value) {
    return value + 273.15;
}

double fahrenheitToKelvin(double fahrenheit) {
    double celsiusVal = (fahrenheit - 32.0) * 5/9;
    double kelvinVal = celsiusVal + 273.15;
    return kelvinVal;
}

