#include <stdio.h>

#include "includes/calculator.h"

int main() {
    int mode = 1;
    printf("====== Calculator ======\n");
    printf("Insert mode\n");
    printf("0) Add\n");
    printf("1) Multiply\n");
    printf("2) Divide\n");
    printf("3) Raise to the power of\n");
    printf("Mode: \n");
    
    double firstVal = 42;
    double secondVal = 5;

    printf("First value: ");
    printf("Second value: ");

    double result = calculate(mode, firstVal, secondVal);
    printf("Result: %f\n", result);
}
