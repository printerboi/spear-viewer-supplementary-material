//
// Created by maximilian on 02.09.24.
//

#ifndef CALCULATOR_H
#define CALCULATOR_H



double calculate(int mode, double a, double b);

double pow(double a, double b);


#endif //CALCULATOR_H
