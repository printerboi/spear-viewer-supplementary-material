#ifndef CEASAR_H
#define CEASAR_H

#include <string>

void encrypt(char* input, int shift);

char rotate(char c, int shift);

#endif //CEASAR_H
