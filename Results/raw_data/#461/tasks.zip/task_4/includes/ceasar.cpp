#include "ceasar.h"


char rotate(char c, int shift) {
    char rotated = c;

    if (islower(c)) {
        rotated = (c - 'a' + shift) % 26 + 'a';
    }

    if (isupper(c)) {
        char offset = 'A';
        rotated = (c - 'A' + shift) % 26 + 'A';
    }

    if (isdigit(c)) {
        rotated = (c - '0' + shift) % 10 + '0';
    }

    return rotated;
}

void encrypt(char* msg, int shift){
  while(*msg) {
    *msg = rotate(*msg, shift);
    msg++;
  }
}
