#include <stdio.h>
#include "includes/ceasar.h"

int main() {
    char msg[] = "I am a secret message!";
    int shift = 10;

    encrypt(msg, shift);
    //result = encrypt(input, shift);

    printf("%s\n", msg);
    //std::cout << msg << std::endl;

    return 0;
}

// all: 1844706
// main: 14217