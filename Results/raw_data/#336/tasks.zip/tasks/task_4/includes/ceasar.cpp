#include "ceasar.h"


char rotate(char c, int shift) {
    char offset;

    if (isdigit(c)) {
        return (c - '0' + shift) % 10 + '0';
    }

    if (isupper(c)) {
        offset = 'A';
    } else {
        char offset = 'a';
    }

    char base = c - offset;
    return (base + shift) % 26 + offset;
    
}

std::string encrypt(std::string plainText, int shift){
  std::string cipherText;
  //cipherText.reserve(plainText.length());
  //255, 100, 9

  for(int i = 0; i < plainText.length(); i++) {
      char c = plainText.at(i);
      char rotated = rotate(c, shift);
      cipherText += rotated;
  }

  return cipherText;
}
