//
// Created by maximilian on 05.07.24.
//

#ifndef CSV_READER_H
#define CSV_READER_H
#include <string>
#include <vector>

std::vector<std::vector<double>> read_in_temps(std::string filename);


#endif //CSV_READER_H
