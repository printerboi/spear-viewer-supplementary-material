#include "ceasar.h"


char rotate(char c, int shift) {
    //char rotated = c;

    if (islower(c)) {
        //char offset = 'a';
        //char base = c - 'a';
        //char globaloffset = 'a';
        return ((c - 'a') + shift) % 26 + 'a';
    }

    if (isupper(c)) {
        char offset = 'A';
        return (c - 'A' + shift) % 26 + offset;
    }

    if (isdigit(c)) {
        return (c - '0' + shift) % 10 + '0';
    }

    return c;
}

std::string encrypt(const std::string& plainText, int shift){
  std::string cipherText;

  for(int i = 0; i < plainText.length(); i++) {
      //char c = plainText.at(i);
      //char rotated = rotate(plainText.at(i), shift);
      cipherText += rotate(plainText.at(i), shift);
  }

  return cipherText;
}
