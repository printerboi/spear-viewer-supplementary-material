#include <iostream>
#include <string>
#include "includes/ceasar.h"

int main() {
    //std::string input = "I am a secret message!";
    //int shift = 10;

    //std::string result="";
    //std::string result = encrypt(input, 10);
    //result = encrypt(input, shift);

    std::cout << encrypt("I am a secret message!", 10) << std::endl;

    return 0;
}
