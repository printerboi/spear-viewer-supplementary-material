# OpenSSL handshake

The openssl handshake program makes use of the openssl crypto library to implement a simple program that receives a URL from the user and tries to perform a SSL handshake with the host.

The code uses openssl als library.

The order of operations should not be altered:

Further information about the methods provided by openssl can be found [here](https://docs.openssl.org/master/man1/)