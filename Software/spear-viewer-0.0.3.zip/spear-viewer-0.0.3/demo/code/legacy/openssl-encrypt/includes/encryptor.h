#include <string>
#include <openssl/crypto.h>
#include <openssl/bn.h>
#include <iostream>
#include <fstream>
#include <sstream>


void encrypt(std::string plaintext);

void writeOuput(std::string output);