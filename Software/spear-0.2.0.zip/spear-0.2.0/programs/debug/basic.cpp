int main(){
    int a = 10;

    if(a < 100){
        a++;
    }else{
        a--;
    }

    return 0;
}