#include <cmath>

int main(){
    double a = sqrt(64);
    a = a + 10;

    return 0;
}