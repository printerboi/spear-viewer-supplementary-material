//
// Created by max on 13.01.23.
//

int main(){
    int a = 0;
    for (int i = 0; i < 1; ++i) {
        for (int j = 0; j < 1; ++j) {
            if(a == 0){
                for (int k = 0; k < 1; ++k) {

                }
            }else{
                for (int k = 0; k < 1; ++k) {

                }
            }

        }
    }



    return 0;
}