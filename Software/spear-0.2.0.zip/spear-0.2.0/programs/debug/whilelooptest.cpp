//
// Created by max on 13.01.23.
//

int main(){
    int a = 0;
    int b = 100;

    while (a < b){
        b--;
        a++;
    }

    return 0;
}