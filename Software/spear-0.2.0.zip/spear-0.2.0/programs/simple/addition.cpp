#include <iostream>

int main(){
    int a = 100;
    int b = 42;

    int result = a + b;

    std::cout << result << "\n";
}
