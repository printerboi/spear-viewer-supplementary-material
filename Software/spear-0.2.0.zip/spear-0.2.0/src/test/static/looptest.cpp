int main(){
    int a = 3;
    for (int i = 0; i < 100; ++i) {
        a--;
    }

    return 0;
}